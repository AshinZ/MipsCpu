### Project1 

#### 文件对应关系

| 文件名 | 对应部件名 |
| ------ | ---------- |
| alu | 算数逻辑模块 |
|ctrl|控制器模块|
|datapath|数据通路模块|
|dm|数据存储模块 用来取数据|
|im|指令存储模块 取指令|
|mips|进入的主模块|
|mux|选择器模块 复用|
|npc|计算下一个pc模块|
|pc|pc模块|
|regfile|寄存器模块|
|signext|符号拓展模块|
|sl2|左移模块|
|testbench|测试运行模块|
|aluCrtl|alu控制器|